from debug import *
from zoodb import *
import rpclib

sys.path.append(os.getcwd())
import readconf

def login(username, password):
    ## Fill in code here.
    pass

def register(username, password):
    ## Fill in code here.
    pass

def check_token(username, token):
    ## Fill in code here.
    pass
